from numpy import *
from scipy.io.wavfile import *
from matplotlib.pyplot import *

data = read('ee.wav')
rate = data[0]
data = data[1][0:300,0]

a = sin(2*pi/100 * array(range(len(data))))
b = cos(2*pi/100 * array(range(len(data))))
c = sin(2*pi/50 * array(range(len(data))))
d = cos(2*pi/50 * array(range(len(data))))
e = sin(2*pi/25 * array(range(len(data))))
f = cos(2*pi/25 * array(range(len(data))))
g = sin(2*pi/12.5 * array(range(len(data))))
h = cos(2*pi/12.5 * array(range(len(data))))

plot(array(range(len(data))), data, 'k')
plot(range(len(data)), sum(data * a) * a / (sum(a * a)) + sum(data * b) * b / (sum(b * b)), 'r')
plot(range(len(data)), sum(data * c) * c / (sum(c * c)) + sum(data * d) * d / (sum(d * d)), 'g')
plot(range(len(data)), sum(data * e) * e / (sum(e * e)) + sum(data * f) * f / (sum(f * f)), 'b')
plot(range(len(data)), sum(data * g) * g / (sum(g * g)) + sum(data * h) * h / (sum(h * h)), 'y')
show()
