\version "2.12.0"  % necessary for upgrading to future LilyPond versions.

\score {
	\relative c'{ <c c>1 r <c cis> r <c d> r <c dis> r <c e> r <c f> r <c fis> r <c g'> r <c gis'> r <c a'> r <c ais'> r <c b'> r <c c'> r <c cis'> r <c d'> r <c dis'> r}
	\midi {
		\context {
			\Score
			tempoWholesPerMinute = #(ly:make-moment 72 4)
			}
		}
}
