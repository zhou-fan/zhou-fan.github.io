source('one_way_prediction.R')
library(RMTstat)

# Generate Y from a balanced one-way design with I groups of size J, with
# p x p population group covariance Sigma1 and error covariance Sigma2.
generate_data <- function(I,J,Sigma1,Sigma2,seed=NA) {
  if (!is.na(seed)) { set.seed(seed) }
  n = I*J
  p = nrow(Sigma1)
  eig1 = eigen(Sigma1,symmetric=TRUE)
  eig2 = eigen(Sigma2,symmetric=TRUE)
  alpha = matrix(rnorm(I*p),I,p) %*% sqrt(diag(eig1$values)) %*% t(eig1$vectors)
  eps = matrix(rnorm(n*p),n,p) %*% sqrt(diag(eig2$values)) %*% t(eig2$vectors)
  U = matrix(0,nrow=n,ncol=I)
  for (i in 1:I) { U[((i-1)*J+1):(i*J),i] = 1 }
  Y = U %*% alpha + eps
  return(Y)
}

# Compute canonical mean-square matrices MSA and MSE.
# Input Y is n x p, with rows partitioned into I blocks of size J
compute_mean_squares <- function(Y,J) {
  n = nrow(Y)
  p = ncol(Y)
  if (n %% J != 0)
    stop('Group size does not divide n')
  I = n/J
  V = matrix(0,n,I)
  for (i in 1:I)
    V[((i-1)*J+1):(i*J),i] = 1/sqrt(J)
  VY = t(V)%*%Y
  eY = colSums(Y)/sqrt(n)
  MSA = (t(VY)%*%VY-eY%*%t(eY))/(I-1)
  MSE = (t(Y)%*%Y-t(VY)%*%VY)/(n-I)
  return(list(MSA=MSA,MSE=MSE))
}

# Estimate spike eigenvalues and eigenvectors of Sigma1 and Sigma2, assuming
# Sigma1 and Sigma2 follow a spherical + spikes model with spherical (noise)
# variances v1, v2.
#
# Input Y is n x p, with rows partitioned into I blocks of size J corresponding
# to the balanced one-way design.
#
# If N is provided, then this assumes the spherical noise lies on a subspace
# of effective dimension N. Otherwise, the method uses N = p where p = ncol(Y).
# 
# If plot.t = TRUE, this adds to the current plot window a scatter-plot of
# values
#   ( m0(lamb,a)*t1(lamb,a), m0(lamb,a)*t2(lamb,a) )
# where a=(a1,a2) varies over the half-circle and lamb varies over the outlier
# eigenvalues of a1*MSA+a2*MSE.
estimate_spikes <- function(Y,J,v1,v2,delta,N=NA,plot.t=FALSE) {
  out = compute_mean_squares(Y,J)
  MSA = out$MSA
  MSE = out$MSE
  if (is.na(N)) { N = ncol(Y) }
  n = nrow(Y)
  I = n / J
  # Compute (t1,t2) for outliers over net of (a1,a2) on half circle
  cat('Computing outliers for all (a1,a2) in a net of 100 values\n')
  ngrid = 50
  angles = seq(0,pi,length.out=ngrid+1)[1:ngrid]
  As = cbind(cos(angles),sin(angles))
  Ts = vector("list", length=ngrid)
  for (j in 1:ngrid) {
    Ts[[j]] = list()
    a1 = As[j,1]
    a2 = As[j,2]
    hatSigma = a1*MSA+a2*MSE
    eigs = eigen(hatSigma,symmetric=TRUE,only.values=TRUE)$values
    # Use eigenvalues outside extremal edges of support
    intervals = compute_support_null(N,I,J,a1,a2,v1,v2,delta)
    inds = which(eigs < min(intervals) | eigs > max(intervals))
    for (i in inds) {
      m0 = compute_m0_null(eigs[i],N,I,J,a1,a2,v1,v2)
      t = compute_t(m0,N,I,J,a1,a2,v1,v2)
      Ts[[j]][[paste(i)]] = c(t,m0)
    }
  }
  if (plot.t) {
    tvals = matrix(unlist(Ts),ncol=3,byrow=TRUE)
    points(tvals[,1]*tvals[,3],tvals[,2]*tvals[,3],pch=19,cex=0.3)
    hatSigma = MSA/J-MSE/J
    eigs = eigen(hatSigma,symmetric=TRUE,only.values=TRUE)$values
    intervals = compute_support_null(N,I,J,1/J,-1/J,v1,v2,delta)
    inds = which(eigs < min(intervals) | eigs > max(intervals))
    for (i in inds) {
      m0 = compute_m0_null(eigs[i],N,I,J,1/J,-1/J,v1,v2)
      t = compute_t(m0,N,I,J,1/J,-1/J,v1,v2)
      points(t[1]*m0,t[2]*m0,pch=18,cex=1.5,col='coral')
    }
  }
  # Find places where (t1,t2) crosses the t_r-axis
  spikes = vector("list",length=2)
  for (r in c(1,2)) {
    cat(sprintf('Refining spike estimates for Sigma%d\n',r))
    evalues = numeric(0)
    evectors = matrix(0,ncol(Y),0)
    s = ifelse(r == 1, 2, 1)
    for (j in 1:ngrid) {
      jnext = ifelse(j < ngrid, j+1, 1)
      for (label in names(Ts[[j]])) {
        # Skip unless m_0*t_r is negative, and t_s for same ordered eigenvalue
        # changes sign
        t = Ts[[j]][[label]]
        if (t[r]*t[3] >= 0 || !(label %in% names(Ts[[jnext]]))
                || t[s] * Ts[[jnext]][[label]][s] >= 0) { next }
        # Refine (a1,a2)
        hat_ts <- function(x) {
          a1 = As[j,1]*x+As[jnext,1]*(1-x)
          a2 = As[j,2]*x+As[jnext,2]*(1-x)
          hatSigma = a1*MSA+a2*MSE
          eigs = eigen(hatSigma,symmetric=TRUE,only.values=TRUE)$values
          z = eigs[as.numeric(label)]
          m0 = compute_m0_null(z,N,I,J,a1,a2,v1,v2)
          t = compute_t(m0,N,I,J,a1,a2,v1,v2)
          return(t[s])
        }
        # Estimate eigenvalue and eigenvector
        xopt = uniroot(hat_ts,c(0,1),tol=1e-2,maxiter=10)$root
        a1 = As[j,1]*xopt+As[jnext,1]*(1-xopt)
        a2 = As[j,2]*xopt+As[jnext,2]*(1-xopt)
        hatSigma = a1*MSA+a2*MSE
        out = eigen(hatSigma,symmetric=TRUE)
        z = out$values[as.numeric(label)]
        v = out$vectors[,as.numeric(label)]
        m0 = compute_m0_null(z,N,I,J,a1,a2,v1,v2)
        t = compute_t(m0,N,I,J,a1,a2,v1,v2)
        dt = compute_dm0_dt(m0,N,I,J,a1,a2,v1,v2)
        evalues = c(evalues, z/t[r])
        evectors = cbind(evectors, v)
      }
    }
    if (length(evalues) > 0) {
      sort.inds = order(evalues, decreasing=TRUE)
      evalues = evalues[sort.inds]
      evectors = evectors[,sort.inds,drop=FALSE]
    }
    spikes[[r]] = list(eigenvalues=evalues, eigenvectors=evectors)
  }
  return(list("Sigma1"=spikes[[1]], "Sigma2"=spikes[[2]]))
}

# Test the sphericity null hypothesis Sigma1 = v1*Id and Sigma2 = v2*Id.
#
# The test is performed using the largest eigenvalue of the MANOVA estimate of
# Sigma1 if estimator=='group', or Sigma2 if estimator=='error'.
# 
# If v1 and/or v2 are omitted, they are estimated from the MANOVA matrices.
#
# If N is provided, this tests the null hypothesis that the spherical structure
# is restricted to a subspace of effective dimension N. Otherwise, the test
# uses N = p where p = ncol(Y).
#
# Returns a standard TW_1 test statistic and associated p-value.
test_sphericity <- function(Y,J,estimator='group',v1=NA,v2=NA,N=NA) {
  if (estimator == 'group') {
    a1 = 1/J
    a2 = -1/J
  } else if (estimator == 'error') {
    a1 = 0
    a2 = 1
  } else { 
    stop('Estimator must be A or E')
  }
  MS = compute_mean_squares(Y,J)
  if (is.na(N)) { N = ncol(Y) }
  if (is.na(v1) || is.na(v2)) {
    if (is.na(v1)) { v1 = sum(diag(MS$MSA/J-MS$MSE/J))/N }
    if (is.na(v2)) { v2 = sum(diag(MS$MSE))/N }
  }
  hatSigma = a1*MS$MSA+a2*MS$MSE
  maxeig = max(eigen(hatSigma,symmetric=TRUE,only.values=TRUE)$values)
  n = nrow(Y)
  I = n/J
  # Check edge regularity
  qstar = min(compute_qvalues_null(N,I,J,a1,a2,v1,v2))
  b1 = (N/(I-1))*a1*(J*v1+v2)
  b2 = (N/(n-I))*a2*v2
  if (abs(1+b1/qstar)<1e-2 || abs(1+b2/qstar)<1e-2) {
    cat('WARNING: Rightmost edge may not be regular')
  }
  edges = predict_edges_null(N,I,J,a1,a2,v1,v2)
  ind = length(edges$edges)
  test.stat = (edges$scales[ind]*N)^(2/3)*(maxeig-edges$edges[ind])
  p.val = 1-ptw(test.stat)
  return(list(test.stat=test.stat,p.val=p.val))
}
