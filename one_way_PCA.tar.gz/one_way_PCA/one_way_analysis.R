is.zero <- function(x) (abs(x) < 1e-10)

# Compute m0(z) for the Marcenko-Pastur law mu0 of the matrix
#   hatSigma = a1*MSA + a2*MSE
# under the null hypothesis Sigma1 = v1*Id, Sigma2 = v2*Id.
# If z is real, this computes the continuous extension from the upper-half
# complex plane, and 1/pi * Im m0(z) gives the density of mu0 at z.
compute_m0_null <- function(z,N,I,J,a1,a2,v1,v2) {
  # Possible non-zero eigenvalues of F are b1, b2 with multiplicities d1, d2
  n = I*J
  d1 = I-1
  d2 = n-I
  b1 = (N/d1)*a1*(J*v1+v2)
  b2 = (N/d2)*a2*v2
  # Raise error if z=0 and m0(z) does not exist at z=0
  nnz = 0
  if (!is.zero(b1)) nnz = nnz+d1
  if (!is.zero(b2)) nnz = nnz+d2
  if (N >= nnz && z == 0)
    return(Inf)
  # Rearrange Marcenko-Pastur equation as 0 = N+c1*z+c2*z^2+c3*z^3 and solve
  c3 = N*z*b1*b2
  c2 = N*z*(b1+b2)+(N-d1-d2)*b1*b2
  c1 = N*z+N*(b1+b2)-d1*b1-d2*b2
  if (is.zero(c3) & is.zero(c2)) {
    roots = polyroot(c(N,c1))
  } else if (is.zero(c3)) {
    roots = polyroot(c(N,c1,c2))
  } else {
    roots = polyroot(c(N,c1,c2,c3))
  }
  # Pick correct root: dz is derivative of z0(m)
  dz <- function(m) (1/m^2-d1/N*b1^2/(1+b1*m)^2-d2/N*b2^2/(1+b2*m)^2)
  m0 = c()
  for (root in roots) {
    if (Im(z) > 0 && !is.zero(Im(root)) && Im(root) > 0)
      m0 = c(m0,root)
    if (Im(z) < 0 && !is.zero(Im(root)) && Im(root) < 0)
      m0 = c(m0,root)
    if (Im(z) == 0) {
      if (is.zero(Im(root)) && dz(Re(root)) > 0) {
        # Outside the spectrum
        m0 = c(m0,Re(root))
      } else if (!is.zero(Im(root)) && Im(root) > 0) {
        # Inside the spectrum
        m0 = c(m0,root)
      }
    }
  }
  if (length(m0) != 1)
    stop('Error: multiple roots found for Stieltjes transform m0(z)')
  return(m0[1])
}

# Compute the m-values m_* for edges of supp(mu0) corresponding to the matrix
#   hatSigma = a1*MSA + a2*MSE
# under the null hypothesis Sigma1 = v1*Id, Sigma2 = v2*Id.
# Returns vector of values q_* = 1/m_*, where q_* = 0 if m_* = Inf
compute_qvalues_null <- function(N,I,J,a1,a2,v1,v2) {
  # Possible non-zero eigenvalues of F are b1, b2 with multiplicities d1, d2
  n = I*J
  d1 = I-1
  d2 = n-I
  b1 = (N/d1)*a1*(J*v1+v2)
  b2 = (N/d2)*a2*v2
  # Reparametrization of inverse Stieltjes transform:
  #   f(q) = z0(1/q) = -q + d1/N * q/(1-s1*q) + d2/N * q/(1-s2*q),
  # where s1 = -1/b1, s2 = -1/b2
  # Derivative:
  #   f'(q) = -1 + d1/N * 1/(1-s1*q)^2 + d2/N * 1/(1-s2*q)^2
  # Solve 0 = f'(q) by rearranging as 0 = c0+c1*q+c2*q^2+c3*q^3+c4*q^4
  if (is.zero(b1) && is.zero(b2)) {
    roots = c()
  }
  else if (is.zero(b1)) {
    s2 = -1/b2
    roots = polyroot(c(N-d2,-2*N*s2,N*s2^2))
  } else if (is.zero(b2)) {
    s1 = -1/b1
    roots = polyroot(c(N-d1,-2*N*s1,N*s1^2))
  } else {
    s1 = -1/b1
    s2 = -1/b2
    c0 = N-(d1+d2)
    c1 = -2*N*(s1+s2)+2*d1*s2+2*d2*s1
    c2 = N*(s1^2+s2^2+4*s1*s2)-d1*s2^2-d2*s1^2
    c3 = -2*N*s1*s2*(s1+s2)
    c4 = N*s1^2*s2^2
    roots = polyroot(c(c0,c1,c2,c3,c4))
  }
  # Get real roots q_* of 0 = f'(q)
  roots = Re(roots[which(is.zero(Im(roots)))])
  return(roots)
}

# Compute the intervals of supp(mu0) for the Marcenko-Pastur law of the matrix
#   hatSigma = a1*MSA + a2*MSE
# under the null hypothesis Sigma1 = v1*Id, Sigma2 = v2*Id.
# If delta is provided, computes the delta-neighborhood supp(mu0)_delta.
# Returns
# [ [ L1,R1 ]
#   [ L2,R2 ]
#      ...
#   [ Lk,Rk ] ]
# where each [Li,Ri] is an interval of supp(mu0) or supp(mu0)_delta.
compute_support_null <- function(N,I,J,a1,a2,v1,v2,delta=0) {
  # Possible non-zero eigenvalues of F are b1, b2 with multiplicities d1, d2
  n = I*J
  d1 = I-1
  d2 = n-I
  b1 = (N/d1)*a1*(J*v1+v2)
  b2 = (N/d2)*a2*v2
  # Edges are z0(m_*) for m-values m_*; input q is 1/m_*
  roots = compute_qvalues_null(N,I,J,a1,a2,v1,v2)
  z0q <- function(q) (-q+d1/N*b1*q/(b1+q)+d2/N*b2*q/(b2+q))
  intervals = matrix(0,nrow=length(roots)/2, ncol=2)
  if (length(roots) > 0) {
    roots = sort(roots, decreasing=TRUE) # This will sort edges increasingly
    if (length(roots) %% 2 != 0)
      stop('Error: Odd number of support edges found')
    for (i in 1:(length(roots)/2)) {
      Eleft = z0q(roots[2*i-1])
      Eright = z0q(roots[2*i])
      intervals[i,] = c(Eleft-delta,Eright+delta)
    }
  }
  # If rank deficient, add interval for point mass at 0
  nnz = 0
  if (!is.zero(b1)) nnz = nnz+d1
  if (!is.zero(b2)) nnz = nnz+d2
  if (N > nnz) { intervals = rbind(intervals, c(-delta,delta)) }
  # Sort intervals by left endpoint and merge overlapping
  intervals = intervals[order(intervals[,1]),,drop=FALSE]
  i = 1
  while (i < nrow(intervals)) {
    diff = intervals[i,2]-intervals[i+1,1]
    if (is.zero(diff) || diff > 0) {
      intervals[i,2] = max(intervals[i,2], intervals[i+1,2])
      intervals = intervals[-(i+1),,drop=FALSE]
    } else {
      i = i+1
    }
  }
  return(intervals)
}

# Compute t1(z) and t2(z) for the model
#   hatSigma = a1*MSA + a2*MSE
# under the null hypothesis Sigma1 = v1*Id, Sigma2 = v2*Id
# Takes as input m0(z) from compute_m0_null
compute_t <- function(m0,N,I,J,a1,a2,v1,v2) {
  n = I*J
  d1 = I-1
  d2 = n-I
  b1z = a1/(1+(N/d1)*a1*(J*v1+v2)*m0)
  b2z = a2/(1+(N/d2)*a2*v2*m0)
  t1 = J*b1z
  t2 = b1z+b2z
  return(c(t1,t2))
}

# Compute dm0(z), dt1(z), and dt2(z) for the model
#   hatSigma = a1*MSA + a2*MSE
# under the null hypothesis Sigma1 = v1*Id, Sigma2 = v2*Id
# Takes as input m0(z) from compute_m0_null
compute_dm0_dt <- function(m0,N,I,J,a1,a2,v1,v2) {
  # Possible non-zero eigenvalues of F are b1, b2 with multiplicities d1, d2
  n = I*J
  d1 = I-1
  d2 = n-I
  b1 = (N/d1)*a1*(J*v1+v2)
  b2 = (N/d2)*a2*v2
  # dm0(z) is 1/dz0(m)
  dz0 = 1/m0^2-d1/N*b1^2/(1+m0*b1)^2-d2/N*b2^2/(1+m0*b2)^2
  dm0 = 1/dz0
  db1z = -dm0*(N/d1)*a1^2*(J*v1+v2)/(1+(N/d1)*a1*(J*v1+v2)*m0)^2
  db2z = -dm0*(N/d2)*a2^2*v2/(1+(N/d2)*a2*v2*m0)^2
  dt1 = J*db1z
  dt2 = db1z+db2z
  return(c(dm0,dt1,dt2))
}

# Compute w11(z), w12(z), and w22(z) for the model
#   hatSigma = a1*MSA + a2*MSE
# under the null hypothesis Sigma1 = v1*Id, Sigma2 = v2*Id
# Takes as input m0(z) from compute_m0_null
compute_w <- function(m0,N,I,J,a1,a2,v1,v2) {
  n = I*J
  d1 = I-1
  d2 = n-I
  b1z = a1/(1+(N/d1)*a1*(J*v1+v2)*m0)
  b2z = a2/(1+(N/d2)*a2*v2*m0)
  w11 = J^2*(N/d1)*b1z^2
  w12 = J*(N/d1)*b1z^2
  w22 = (N/d1)*b1z^2+(N/d2)*b2z^2
  return(c(w11,w12,w22))
}

# Predict edge behavior of the Marcenko-Pastur law mu0 for the matrix
#   hatSigma = a1*MSA + a2*MSE
# under the null hypothesis Sigma1 = v1*Id, Sigma2 = v2*Id.
#
# For MANOVA estimator of Sigma1, set a1 = 1/J, a2 = -1/J
# For MANOVA estimator of Sigma2, set a1 = 0, a2 = 1
#
# Assumes a balanced design with I groups of J individuals, and p traits.
#
# Returns:
#   edges: List of edges E_*, sorted increasingly.
#   scales: Associated Tracy-Widom scales gamma.
#
# If E_* is a right edge and z is the largest eigenvalue near E_*,
# then (gamma*p)^(2/3)*(z-E_*) is approximated distributed as TW_1.
# If E_* is a left edge, this holds for (E_*-z).
# (Accuracy of TW_1 approximation depends on regularity of E_*.)
predict_edges_null <- function(p,I,J,a1,a2,v1,v2) {
  # Possible non-zero eigenvalues of F are b1, b2 with multiplicities d1, d2
  N = p
  n = I*J
  d1 = I-1
  d2 = n-I
  b1 = (N/d1)*a1*(J*v1+v2)
  b2 = (N/d2)*a2*v2
  # Edges and scales are z0(m_*) and sqrt(2/|z0''(m_*)|) for m-values m_*;
  # Input q is 1/m_*
  roots = compute_qvalues_null(N,I,J,a1,a2,v1,v2)
  if (length(roots) > 0)
    roots = sort(roots, decreasing=TRUE) # This will sort edges increasingly
  z0q <- function(q) (-q+d1/N*b1*q/(b1+q)+d2/N*b2*q/(b2+q))
  z02q <- function(q) (-2*q^3+2*d1/N*(b1*q)^3/(b1+q)^3+2*d2/N*(b2*q)^3/(b2+q)^3)
  edges = sapply(roots, z0q)
  scales = sapply(roots, function(q) sqrt(2/abs(z02q(q))))
  return(list(edges=edges,scales=scales))
}

# Predict outlier behavior for the matrix
#   hatSigma = a1*MSA + a2*MSE
# when Sigma1 = v1*Id+V1*Theta1*V1', Sigma2 = v2*Id+V2*Theta2*V2'.
#
# For MANOVA estimator of Sigma1, set a1 = 1/J, a2 = -1/J
# For MANOVA estimator of Sigma2, set a1 = 0, a2 = 1
#
# Assumes a balanced design with I groups of J individuals, and p traits.
# Theta1, Theta2 should be diagonal l1 x l1 and l2 x l2, and V1 and V2 should
# be p x l1 and p x l2.
# 
# Returns:
#   outliers: Predicted outlier eigenvalue means
#   sds: Predicted outlier eigenvalue standard deviations
#   projections: Predicted outlier eigenvector projections onto span(V1,V2)
#      (Each column corresponds to one outlier.)
predict_outliers <- function(p,I,J,a1,a2,v1,v2,Theta1,Theta2,V1,V2) {
  l1 = ncol(V1)
  l2 = ncol(V2)
  if (dim(Theta1) != c(l1,l1) || dim(Theta2) != c(l2,l2)
      || dim(V1) != c(p,l1) || dim(V2) != c(p,l2))
    stop('Incorrect matrix dimensions')
  outliers = c()
  sds = c()
  projections = matrix(0,p,0)
  if (l1 == 0 && l2 == 0)
    return(list(outliers=outliers,sds=sds,projections=projections))
  # Rotate and project into dimension l1+l2
  qr.out = qr(cbind(V1,V2))
  V = qr.R(qr.out)
  Q = qr.Q(qr.out)
  if (l1 == 0) { V1 = matrix(0,nrow(V),0) }
  else { V1 = V[,1:l1] }
  if (l2 == 0) { V2 = matrix(0,nrow(V),0) }
  else { V2 = V[,(l1+1):(l1+l2)] }
  P1 = V1 %*% Theta1 %*% t(V1)
  P2 = V2 %*% Theta2 %*% t(V2)
  # For each interval of R \ supp(mu0) and each ordered eigenvalue mu_k(lamb) of
  # T(lamb), search for at most one lamb where mu_k(lamb) = 0
  N = p-l1-l2
  support = compute_support_null(N,I,J,a1,a2,v1,v2)
  eigT <- function(z,k) {
    m0 = compute_m0_null(z,N,I,J,a1,a2,v1,v2)
    t = compute_t(m0,N,I,J,a1,a2,v1,v2)
    Tmat = -1/m0*diag(nrow=l1+l2)-t[1]*P1-t[2]*P2
    return(eigen(Tmat,only.values=TRUE,symmetric=TRUE)$values[k])
  }
  for (i in 1:(nrow(support)+1)) {
    # Get lower endpoint of interval of support complement
    if (i == 1) {
      # For leftmost interval, guarantee T(lower) is negative-definite
      lower = support[i,1]-1
      maxeig = eigT(lower,1)
      if (maxeig > 0) { lower = lower - maxeig }
    } else {
      lower = support[i-1,2]+1e-10
    }
    # Get upper endpoint of interval of support complement
    if (i == nrow(support)+1) {
      # For rightmost interval, guarantee T(upper) is positive-definite
      upper = support[i-1,2]+1
      mineig = eigT(upper,l1+l2)
      if (mineig < 0) { upper = upper - mineig }
    } else {
      upper = support[i,1]-1e-10
    }
    for (k in 1:(l1+l2)) {
      if (eigT(lower,k) <= 0 && eigT(upper,k) >= 0) {
        z = uniroot(function(z) eigT(z,k), c(lower,upper))$root
        outliers = c(outliers,z)
        # Predict standard deviation and eigenvector projection
        m0 = compute_m0_null(z,N,I,J,a1,a2,v1,v2)
        t = compute_t(m0,N,I,J,a1,a2,v1,v2)
        Tmat = -1/m0*diag(nrow=l1+l2)-t[1]*P1-t[2]*P2
        v = eigen(Tmat,symmetric=TRUE)$vectors[,k]
        out = compute_dm0_dt(m0,N,I,J,a1,a2,v1,v2)
        dm0 = out[1]
        dt1 = out[2]
        dt2 = out[3]
        dT = dm0/m0^2*diag(nrow=l1+l2)-dt1*P1-dt2*P2
        vdTv = (t(v)%*%dT%*%v)[1,1]
        proj = (Q%*%v)/sqrt(vdTv)
        projections = cbind(projections, proj)
        A = 2/(N*vdTv^2)
        B = (vdTv-1)^2/dm0
        out = compute_w(m0,N,I,J,a1,a2,v1,v2)
        w11 = out[1]
        w12 = out[2]
        w22 = out[3]
        vSigma1v = v1+(t(v)%*%P1%*%v)[1,1]
        vSigma2v = v2+(t(v)%*%P2%*%v)[1,1]
        C = w11*vSigma1v^2+2*w12*vSigma1v*vSigma2v+w22*vSigma2v^2
        sds = c(sds, sqrt(A*(B+C)))
      }
    }
  }
  return(list(outliers=outliers,sds=sds,projections=projections))
}

# Compute the approximating eigenvalue law mu0 for the matrix
#   hatSigma = a1*MSA + a2*MSE
# when the population covariances are Sigma1, Sigma2.
#
# For MANOVA estimator of Sigma1, set a1 = 1/J, a2 = -1/J
# For MANOVA estimator of Sigma2, set a1 = 0, a2 = 1
#
# Assumes a balanced design with I groups of J individuals. The number of
# traits is given by the dimensions of Sigma1 and Sigma2.
# 
# Returns the density of mu0 at the given grid of x-values. If mu0 has a point
# mass at 0, this is omitted from the density.
# 
# If Sigma1, Sigma2 are spherical, this solves the Marcenko-Pastur equation,
# and eps, tol are ignored.
#
# Otherwise, this uses fixed-point recursions, with relative convergence
# tolerance tol, to compute the convolution of mu0 with Cauchy(0,eps).
# This is significantly faster when Sigma1, Sigma2 are diagonal.
predict_bulk <- function(xgrid,I,J,a1,a2,Sigma1,Sigma2,eps=1e-4,tol=1e-5) {
  p = nrow(Sigma1)
  if (p != ncol(Sigma1) || p != ncol(Sigma2) || p != nrow(Sigma2))
    stop('Incompatible dimensions of Sigma1 and Sigma2')
  n = I*J
  d1 = I-1
  d2 = n-I
  diagonal = (is.zero(max(abs(Sigma1-diag(diag(Sigma1))))) &&
          is.zero(max(abs(Sigma2-diag(diag(Sigma2))))))
  if (diagonal && is.zero(var(diag(Sigma1))) && is.zero(var(diag(Sigma2)))) {
    # Spherical case
    v1 = Sigma1[1,1]
    v2 = Sigma2[1,1]
    mgrid = sapply(xgrid, function(z) compute_m0_null(z,p,I,J,a1,a2,v1,v2))
    fgrid = Im(mgrid)/pi
  } else {
    # General case
    if (diagonal) {
      diag1 = diag(Sigma1)
      diag2 = diag(Sigma2)
      nnz = min(d1,length(which(!is.zero(a1*(J*diag1+diag2)))))
      nnz = nnz + min(d2,length(which(!is.zero(a2*diag2))))
    } else {
      Id = diag(nrow=p)
      SigmaAll = cbind(Sigma1,Sigma2)
      eigs = eigen(a1*(J*Sigma1+Sigma2),symmetric=TRUE,only.values=TRUE)$values
      nnz = min(d1,length(which(!is.zero(eigs))))
      eigs = eigen(a2*Sigma2,symmetric=TRUE,only.values=TRUE)$values
      nnz = nnz + min(d2,length(which(!is.zero(eigs))))
    }
    update_x <- function(z,y) {
      x = numeric(2)
      if (diagonal) {
        # Diagonal matrix inversion
        x[1] = -1/I*sum(diag1/(z+y[1]*diag1+y[2]*diag2))
        x[2] = -1/n*sum(diag2/(z+y[1]*diag1+y[2]*diag2))
      } else {
        # General matrix inversion
        M = solve(z*Id+y[1]*Sigma1+y[2]*Sigma2,SigmaAll)
        x[1] = -1/I*sum(diag(M[,1:p]))
        x[2] = -1/n*sum(diag(M[,(p+1):(2*p)]))
      }
      return(x)
    }
    update_y <- function(x) {
      y = numeric(2)
      y[1] = -a1*J/(1+(n/d1)*a1*(x[1]+x[2]))
      y[2] = -a1/(1+(n/d1)*a1*(x[1]+x[2]))-a2/(1+(n/d2)*a2*x[2])
      return(y)
    }
    fgrid = numeric(length(xgrid))
    ysave = matrix(0,2,2)
    for (i in 1:length(xgrid)) {
      cat(sprintf('  Computing density at x = %0.3f\n',xgrid[i]))
      z = xgrid[i]+eps*1i
      # Warm-start y by linear interpolation from previous two grid values
      y = (ysave[2,]-ysave[1,])+ysave[2,]
      repeat {
        x = update_x(z,y)
        y_new = update_y(x)
        end = (sqrt(sum(Mod(y-y_new)^2)) < tol*sqrt(sum(Mod(y)^2)))
        y = y_new
        if (end) { break }
      }
      if (diagonal) {
        # Diagonal matrix inversion
        m0 = -1/p*sum(1/(z+y[1]*diag1+y[2]*diag2))
      } else {
        # General matrix inversion
        M = solve(z*Id+y[1]*Sigma1+y[2]*Sigma2,Id)
        m0 = -1/p*sum(diag(M))
      }
      # Remove contribution to m0 from point mass at 0
      if (nnz < p) {
        m0 = m0 + (p-nnz)/p*1/z
      }
      fgrid[i] = max(0,Im(m0)/pi)
      ysave[1,] = ysave[2,]
      ysave[2,] = y
    }
  }
  return(fgrid)
}

