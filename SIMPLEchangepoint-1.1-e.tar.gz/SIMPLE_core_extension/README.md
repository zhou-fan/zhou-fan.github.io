SIMPLE changepoint core package extension
=========================================
This package implements the SIMultaneous Penalized Likelihood Estimate (SIMPLE)
changepoint detection method developed in Fan et al. "Identifying localized
changes in large systems: Change-point detection for biomolecular simulations."

It extends the implementation previously released by the authors to include
inference procedures using the Laplace and normal likelihood models with
changing mean and/or scale, and the Poisson and Bernoulli likelihood models.

PREREQUISITES
------------------------------------------------
* [python] - "A programming language that lets you work quickly and integrate systems more effectively."
* [numpy] - "The fundamental package for scientific computing with Python."
* [scipy] - "A Python-based ecosystem of open-source software for mathematics, science, and engineering."
* [mpi4py] (optional) - Python bindings for MPI (requires a working MPI installation, such as Open MPI, MPICH 2, or LAM/MPI.)
* [pytables] (optional) - A package for managing large datasets based on the HDF5 library (installed separately.)

[python]:https://www.python.org/
[numpy]:http://www.numpy.org/
[scipy]:http://www.scipy.org/
[mpi4py]:http://www.mpi4py.scipy.org
[pytables]:http://www.pytables.org

INSTALL
------------------------------------------------
This package requires a working installation of Python 2.7 and numpy. From a
terminal, cd to this directory and execute

  python setup.py build
  python setup.py install

To test your installation, cd to the tests subdirectory and execute

  python ut.py
  ComputeSIMPLEChanges data.csv out.json --lambda 20 --verbose

To install to a local directory (e.g. if you do not have administrative access
to the default install location), execute

  python setup.py build
  python setup.py install --prefix=<YOUR-INSTALL-LOCATION>

where <YOUR-INSTALL-LOCATION> should be replaced by a local installation
directory. Ensure that <YOUR-INSTALL-LOCATION>/lib/python2.7/site-packages and
<YOUR-INSTALL-LOCATION>/bin are added to your PYTHONPATH and PATH environment
variables, respectively (e.g. by adding the lines

  export PATH=<YOUR-INSTALL-LOCATION>/bin:$PATH
  export PYTHONPATH=<YOUR-INSTALL-LOCATION>/lib/python2.7/site-packages:$PYTHONPATH

to your .bashrc or equivalent file).

USAGE
------------------------------------------------------
This package comprises a Python library and a Python script based on that
library. To run the script from the command line using the default Laplace
likelihood model with changing mean and scale:

  ComputeSIMPLEChanges datafile outfile --lambda LAMBDA --verbose

where datafile is either a CSV-formatted data matrix (with rows indexing
sequences and columns indexing sequential positions/time points) or an HDF5
file (with .h5 file-name extension) containing such a data matrix, outfile is
the output file for the detected changes, and LAMBDA is the size of the
penalty.

For large data sets, it is recommended to run in parallel mode using MPI:

  mpiexec -n nprocs ComputeSIMPLEChanges datafile outfile --lambda LAMBDA
      --verbose --parallel

For further options (including other likelihood models) and documentation:

  ComputeSIMPLEChanges --help

One may also use the library within a Python session. To read a CSV-formatted
data matrix 'X.csv' (with rows indexing sequences and columns indexing
sequential positions/time points) into Python:

  import numpy
  X = numpy.loadtxt('X.csv', delimiter=',')

To run the changepoint detection algorithm using the default Laplace likelihood
model with changing mean and scale (and lambda=20):

  import SIMPLEchangepoint
  changes = SIMPLEchangepoint.ComputeChanges(X, 20)

For further options (including other likelihood models) and documentation:

  help(SIMPLEchangepoint)

