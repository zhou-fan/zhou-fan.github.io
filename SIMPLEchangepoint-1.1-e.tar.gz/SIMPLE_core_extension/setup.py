from distutils.core import setup
from distutils.extension import Extension
from distutils.sysconfig import get_python_inc
import numpy

exec(open('SIMPLEchangepoint/_version.py').read())

setup(name='SIMPLEchangepoint',
        version=__version__,
        description='SIMultaneous Penalized Likelihood Estimation of changepoints',
        author='Zhou Fan',
        packages=['SIMPLEchangepoint'],
        platforms=['Linux'],
        ext_modules=[Extension('SIMPLEchangepoint._c_funcs',
            ['src/univariate_changes.cpp',
                'src/laplace_mean_scale_model.cpp',
                'src/normal_mean_var_model.cpp',
                'src/normal_mean_model.cpp',
                'src/normal_var_model.cpp',
                'src/poisson_model.cpp',
                'src/bernoulli_model.cpp',
                'src/laplace_scale_model.cpp',
                'src/laplace_mean_model.cpp',
                'src/py_extension.cpp'],
            include_dirs=[get_python_inc(), numpy.get_include()])],
        scripts=['scripts/ComputeSIMPLEChanges']
        )
