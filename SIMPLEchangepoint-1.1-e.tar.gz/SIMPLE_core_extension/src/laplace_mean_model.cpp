#include "laplace_mean_model.hpp"
#include <math.h>
#include <limits>

using namespace SIMPLE_changepoint;

LaplaceMeanSuffStat::LaplaceMeanSuffStat(int _t, double _mean,
        double _scale) {
    t = _t;
    scale = _scale;
    n = 0;
    med = 0;
    total_var = 0;
    cost = 0;
    prune_t = -1;
}

void LaplaceMeanSuffStat::add(double x) {
    ++n;
    if (highs.size() == lows.size()) {
        if (highs.size() == 0 || x < highs.top()) {
            lows.push(x);
            med = lows.top();
            total_var += med - x;
        } else {
            highs.push(x);
            med = highs.top();
            total_var += x - med;
        }
    } else if (highs.size() < lows.size()) {
        if (x >= lows.top()) {
            highs.push(x);
            med = (lows.top() + highs.top()) / 2;
            total_var += (highs.top() - lows.top()) / 2;
            total_var += x - med;
        } else {
            highs.push(lows.top());
            lows.pop();
            lows.push(x);
            med = (lows.top() + highs.top()) / 2;
            total_var += (highs.top() - lows.top()) / 2;
            total_var += med - x;
        }
    } else {
        if (x <= highs.top()) {
            lows.push(x);
            med = (lows.top() + highs.top()) / 2;
            total_var += (highs.top() - lows.top()) / 2;
            total_var += med - x;
        } else {
            lows.push(highs.top());
            highs.pop();
            highs.push(x);
            med = (lows.top() + highs.top()) / 2;
            total_var += (highs.top() - lows.top()) / 2;
            total_var += x - med;
        }
    }
}

double LaplaceMeanSuffStat::ll() {
    if (n < MIN_SEP)
        return -std::numeric_limits<double>::infinity();
    else
        return -total_var / scale + n * log(2 * scale);
}

