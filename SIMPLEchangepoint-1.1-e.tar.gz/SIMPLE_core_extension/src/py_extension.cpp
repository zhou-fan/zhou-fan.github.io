/*
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <Python.h>
#include <numpy/arrayobject.h>
#include <sstream>
#include "univariate_changes.hpp"
#include "laplace_mean_scale_model.hpp"
#include "laplace_scale_model.hpp"
#include "laplace_mean_model.hpp"
#include "normal_mean_var_model.hpp"
#include "normal_mean_model.hpp"
#include "normal_var_model.hpp"
#include "poisson_model.hpp"
#include "bernoulli_model.hpp"

using namespace SIMPLE_changepoint;

static PyObject* py_find_changes(PyObject* self, PyObject* args) {
    PyObject* arg1 = NULL;
    PyObject* arg2 = NULL;
    char* model = NULL;
    double mean, scale;
    if (!PyArg_ParseTuple(args, "OOsdd", &arg1, &arg2, &model, &mean,
                &scale)) return NULL;
    PyObject* np_data = PyArray_FROM_OTF(arg1, NPY_FLOAT32, NPY_IN_ARRAY);
    PyObject* np_penalties = PyArray_FROM_OTF(arg2, NPY_FLOAT32,
            NPY_IN_ARRAY);
    if (np_data == NULL || np_penalties == NULL) {
        Py_XDECREF(np_data);
        Py_XDECREF(np_penalties);
        return NULL;
    }
    int T = PyArray_DIM(np_data, 0);
    if (T != PyArray_DIM(np_penalties, 0) + 1) {
        PyErr_SetString(PyExc_ValueError,
                "Dimensions of data and penalty are not compatible");
        Py_DECREF(np_data);
        Py_DECREF(np_penalties);
        return NULL;
    }
    int J = PyArray_DIM(np_data, 1);
    float* data = (float*) PyArray_DATA(np_data);
    float* penalties = (float*) PyArray_DATA(np_penalties);
    std::list<int> chgs;
    try {
        if (strcmp(model, "laplace_mean_scale") == 0) {
            chgs = find_changes<LaplaceMeanScaleSuffStat>(data, penalties,
                    T, J);
        } else if (strcmp(model, "normal_mean_var") == 0) {
            chgs = find_changes<NormalMeanVarSuffStat>(data, penalties,
                    T, J);
        } else if (strcmp(model, "normal_mean") == 0) {
            chgs = find_changes<NormalMeanSuffStat>(data, penalties, T, J,
                    mean, scale);
        } else if (strcmp(model, "normal_var") == 0) {
            chgs = find_changes<NormalVarSuffStat>(data, penalties, T, J,
                    mean, scale);
        } else if (strcmp(model, "poisson") == 0) {
            chgs = find_changes<PoissonSuffStat>(data, penalties, T, J,
                    mean, scale);
        } else if (strcmp(model, "bernoulli") == 0) {
            chgs = find_changes<BernoulliSuffStat>(data, penalties, T, J,
                    mean, scale);
        } else if (strcmp(model, "laplace_scale") == 0) {
            chgs = find_changes<LaplaceScaleSuffStat>(data, penalties, T, J,
                    mean, scale);
        } else if (strcmp(model, "laplace_mean") == 0) {
            chgs = find_changes<LaplaceMeanSuffStat>(data, penalties, T, J,
                    mean, scale);
        } else {
            PyErr_SetString(PyExc_ValueError, "Unrecognized model");
            Py_DECREF(np_data);
            Py_DECREF(np_penalties);
            return NULL;
        }
    } catch (std::exception& e) {
        std::stringstream ss;
        ss << "Execution error: " << e.what();
        PyErr_SetString(PyExc_RuntimeError, ss.str().c_str());
        Py_DECREF(np_data);
        Py_DECREF(np_penalties);
        return NULL;
    }
    PyObject* changes = PyList_New(0);
    for (std::list<int>::iterator iter = chgs.begin(); iter != chgs.end();
            ++iter) {
        PyObject* num = PyInt_FromLong(*iter);
        PyList_Append(changes, num);
        Py_DECREF(num);
    }
    Py_DECREF(np_data);
    Py_DECREF(np_penalties);
    return changes;
} 

static PyObject* py_ll_difference(PyObject* self, PyObject* args) {
    PyObject* arg1 = NULL;
    int prev_change, next_change, start, end;
    char* model;
    double mean, scale;
    if (!PyArg_ParseTuple(args, "Oiiiisdd", &arg1, &prev_change,
                &next_change, &start, &end, &model, &mean, &scale))
        return NULL;
    PyObject* np_data = PyArray_FROM_OTF(arg1, NPY_FLOAT32, NPY_IN_ARRAY);
    if (np_data == NULL) return NULL;
    int T = PyArray_DIM(np_data, 0);
    if (start < 0 || start >= end || T < end) {
        PyErr_SetString(PyExc_ValueError, "Dimensions of data are not "
                "compatible with start and end values");
        Py_DECREF(np_data);
        return NULL;
    }
    float* data = (float*) PyArray_DATA(np_data);
    npy_intp out_dims[1];
    *out_dims = end - start + 1;
    PyObject* np_ll_diff = PyArray_SimpleNew(1, out_dims, NPY_FLOAT64);
    double* ll_diff = (double*) PyArray_DATA(np_ll_diff);
    try {
        if (strcmp(model, "laplace_mean_scale") == 0) {
            ll_difference<LaplaceMeanScaleSuffStat>(data, prev_change,
                    next_change, start, end, ll_diff);
        } else if (strcmp(model, "normal_mean_var") == 0) {
            ll_difference<NormalMeanVarSuffStat>(data, prev_change,
                    next_change, start, end, ll_diff);
        } else if (strcmp(model, "normal_mean") == 0) {
            ll_difference<NormalMeanSuffStat>(data, prev_change,
                    next_change, start, end, ll_diff, mean, scale);
        } else if (strcmp(model, "normal_var") == 0) {
            ll_difference<NormalVarSuffStat>(data, prev_change,
                    next_change, start, end, ll_diff, mean, scale);
        } else if (strcmp(model, "poisson") == 0) {
            ll_difference<PoissonSuffStat>(data, prev_change,
                    next_change, start, end, ll_diff, mean, scale);
        } else if (strcmp(model, "bernoulli") == 0) {
            ll_difference<BernoulliSuffStat>(data, prev_change,
                    next_change, start, end, ll_diff, mean, scale);
        } else if (strcmp(model, "laplace_scale") == 0) {
            ll_difference<LaplaceScaleSuffStat>(data, prev_change,
                    next_change, start, end, ll_diff, mean, scale);
        } else if (strcmp(model, "laplace_mean") == 0) {
            ll_difference<LaplaceMeanSuffStat>(data, prev_change,
                    next_change, start, end, ll_diff, mean, scale);
        } else {
            PyErr_SetString(PyExc_ValueError, "Unrecognized model");
            Py_DECREF(np_data);
            return NULL;
        }
    } catch (std::exception& e) {
        std::stringstream ss;
        ss << "Execution error: " << e.what();
        PyErr_SetString(PyExc_RuntimeError, ss.str().c_str());
        Py_DECREF(np_data);
        return NULL;
    }
    Py_DECREF(np_data);
    return np_ll_diff;
}

static PyMethodDef methods[] = {
    {"find_changes", py_find_changes, METH_VARARGS,
        "univariate dynamic programming algorithm"},
    {"ll_difference", py_ll_difference, METH_VARARGS,
        "compute log-likelihood differences"},
    {NULL, NULL, 0, NULL}
};

PyMODINIT_FUNC
init_c_funcs(void) {
    (void)Py_InitModule("_c_funcs", methods);
    import_array();
}
