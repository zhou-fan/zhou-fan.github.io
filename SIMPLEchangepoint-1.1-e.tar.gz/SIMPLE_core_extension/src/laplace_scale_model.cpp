#include "laplace_scale_model.hpp"
#include <math.h>
#include <limits>

using namespace SIMPLE_changepoint;

LaplaceScaleSuffStat::LaplaceScaleSuffStat(int _t, double _mean,
        double _scale) {
    t = _t;
    mean = _mean;
    n = 0;
    absxsum = 0;
    cost = 0;
    prune_t = -1;
}

void LaplaceScaleSuffStat::add(double x) {
    ++n;
    absxsum += fabs(x-mean);
}

double LaplaceScaleSuffStat::ll() {
    if (absxsum == 0 || n < MIN_SEP)
        return -std::numeric_limits<double>::infinity();
    else
        return -n * (1 + log(2 * absxsum / n));
}
