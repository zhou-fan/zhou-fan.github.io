#include "normal_var_model.hpp"
#include <math.h>
#include <limits>

const static double PI = 3.141592654;

using namespace SIMPLE_changepoint;

NormalVarSuffStat::NormalVarSuffStat(int _t, double _mean,
        double _scale) {
    t = _t;
    mean = _mean;
    n = 0;
    xsum = 0;
    xsqsum = 0;
    cost = 0;
    prune_t = -1;
}

void NormalVarSuffStat::add(double x) {
    ++n;
    xsum += x;
    xsqsum += x*x;
}

double NormalVarSuffStat::ll() {
    double var = xsqsum / n - 2 * mean * xsum / n + mean * mean;
    if (var <= 0 || n < MIN_SEP)
        return -std::numeric_limits<double>::infinity();
    else
        return -n/2.0 * (1 + log(2 * PI * var));
}
