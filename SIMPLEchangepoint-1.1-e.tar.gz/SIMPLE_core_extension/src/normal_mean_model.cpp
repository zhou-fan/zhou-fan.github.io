#include "normal_mean_model.hpp"
#include <math.h>
#include <limits>

const static double PI = 3.141592654;

using namespace SIMPLE_changepoint;

NormalMeanSuffStat::NormalMeanSuffStat(int _t, double _mean,
        double _scale) {
    t = _t;
    var = _scale * _scale;
    n = 0;
    xsum = 0;
    xsqsum = 0;
    cost = 0;
    prune_t = -1;
}

void NormalMeanSuffStat::add(double x) {
    ++n;
    xsum += x;
    xsqsum += x*x;
}

double NormalMeanSuffStat::ll() {
    if (xsqsum == 0 || n < MIN_SEP)
        return -std::numeric_limits<double>::infinity();
    else {
        double sample_var = xsqsum / n - (xsum / n) * (xsum / n);
        sample_var = (sample_var > 0 ? sample_var : 0);
        return -n/2.0 * (sample_var / var + log(2 * PI * var));
    }
}
