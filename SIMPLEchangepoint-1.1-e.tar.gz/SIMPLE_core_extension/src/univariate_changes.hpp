#ifndef __SIMPLE_changepoint_univariate_changes_hpp__
#define __SIMPLE_changepoint_univariate_changes_hpp__

#include <list>

namespace SIMPLE_changepoint {

    template<typename SuffStat>
        std::list<int> find_changes(const float* data,
                const float* penalties, int T, int J, double mean=0,
                double scale=1);

    template<typename SuffStat>
        void ll_difference(const float* data, int prev_change,
                int next_change, int start, int end, double* ll_diff,
                double mean=0, double scale=1);

}

#endif
