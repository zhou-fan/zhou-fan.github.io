#ifndef __simple_changepoint_normal_mean_model_hpp__
#define __simple_changepoint_normal_mean_model_hpp__

namespace SIMPLE_changepoint {

    struct NormalMeanSuffStat {
        NormalMeanSuffStat(int _t, double _mean, double _scale);
        void add(double x);
        double ll();

        int t;
        double var;
        int n;
        double xsum;
        double xsqsum;
        double cost;
        int prune_t;
        const static int MIN_SEP = 1;
    };

}
#endif
