/*
Copyright 2012-2014, D. E. Shaw Research.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions, and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright
  notice, this list of conditions, and the following disclaimer in the
  documentation and/or other materials provided with the distribution.

* Neither the name of D. E. Shaw Research nor the names of its
  contributors may be used to endorse or promote products derived from
  this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "univariate_changes.hpp"
#include "laplace_mean_scale_model.hpp"
#include "laplace_scale_model.hpp"
#include "laplace_mean_model.hpp"
#include "normal_mean_var_model.hpp"
#include "normal_mean_model.hpp"
#include "normal_var_model.hpp"
#include "poisson_model.hpp"
#include "bernoulli_model.hpp"
#include <limits>

template<typename SuffStat>
std::list<int> SIMPLE_changepoint::find_changes(const float* data,
        const float* penalties, int T, int J, double mean, double scale) {
    double* vals = new double[T];
    int* prev = new int[T];
    typename std::list<SuffStat> checks;
    checks.push_back(SuffStat(0, mean, scale));
    for (int t = 0; t < SuffStat::MIN_SEP - 1; ++t)
        checks.back().add(data[t]);
    for (int t = SuffStat::MIN_SEP - 1; t < T; ++t) {
        double max_val = -std::numeric_limits<double>::max();
        int max_ind = -1;
        for (typename std::list<SuffStat>::iterator iter = checks.begin();
                iter != checks.end(); ++iter) {
            if (iter->prune_t == t) {
                iter = checks.erase(iter);
                --iter;
                continue;
            }
            iter->add(data[t]);
            double val = iter->ll();
            if (iter->t > 0)
                val += vals[iter->t - 1] - penalties[iter->t - 1];
            iter->cost = val;
            if (val > max_val) {
                max_val = val;
                max_ind = iter->t;
            }
        }
        vals[t] = max_val;
        prev[t] = max_ind;
        for (typename std::list<SuffStat>::iterator iter = checks.begin();
                iter != checks.end(); ++iter) {
            if (t < T-1 && iter->prune_t == -1 && iter->cost < vals[t]
                    - penalties[t])
                iter->prune_t = t + SuffStat::MIN_SEP;
        }
        if (t - SuffStat::MIN_SEP + 2 >= SuffStat::MIN_SEP) {
            checks.push_back(SuffStat(t-SuffStat::MIN_SEP+2, mean, scale));
            for (int s = t - SuffStat::MIN_SEP + 2; s <= t; ++s)
                checks.back().add(data[s]);
        }
    }
    std::list<int> changes;
    int ind = prev[T-1];
    while (ind > 1) {
        changes.push_front(ind);
        ind = prev[ind-1];
    }
    delete[] vals;
    delete[] prev;
    return changes;
}

template<typename SuffStat>
void SIMPLE_changepoint::ll_difference(const float* data, int prev_change,
        int next_change, int start, int end, double* ll_diff, double mean,
        double scale) {
    if (prev_change == start)
        ll_diff[0] = 0;
    SuffStat tmp(0, mean, scale);
    for (int t = prev_change; t < next_change; ++t) {
        tmp.add(data[t]);
        if (t >= start-1 && t < end)
            ll_diff[t-start+1] = tmp.ll();
    }
    double prev_ll = tmp.ll();
    if (prev_ll == -std::numeric_limits<double>::infinity())
        return;
    if (next_change == end)
        ll_diff[end - start] -= prev_ll;
    tmp = SuffStat(0, mean, scale);
    for (int t = next_change - 1; t >= start; --t) {
        tmp.add(data[t]);
        if (t <= end)
            ll_diff[t-start] += tmp.ll() - prev_ll;
    }
    return;
}

template std::list<int> SIMPLE_changepoint::find_changes<
        SIMPLE_changepoint::LaplaceMeanScaleSuffStat>(
        const float* data, const float* penalties, int T, int J,
        double mean, double scale);
template void SIMPLE_changepoint::ll_difference<
        SIMPLE_changepoint::LaplaceMeanScaleSuffStat>(
        const float* data, int prev_change, int next_change, int start,
        int end, double* ll_diff, double mean, double scale);
template std::list<int> SIMPLE_changepoint::find_changes<
        SIMPLE_changepoint::NormalMeanVarSuffStat>(
        const float* data, const float* penalties, int T, int J,
        double mean, double scale);
template void SIMPLE_changepoint::ll_difference<
        SIMPLE_changepoint::NormalMeanVarSuffStat>(
        const float* data, int prev_change, int next_change, int start,
        int end, double* ll_diff, double mean, double scale);
template std::list<int> SIMPLE_changepoint::find_changes<
        SIMPLE_changepoint::NormalMeanSuffStat>(
        const float* data, const float* penalties, int T, int J,
        double mean, double scale);
template void SIMPLE_changepoint::ll_difference<
        SIMPLE_changepoint::NormalMeanSuffStat>(
        const float* data, int prev_change, int next_change, int start,
        int end, double* ll_diff, double mean, double scale);
template std::list<int> SIMPLE_changepoint::find_changes<
        SIMPLE_changepoint::NormalVarSuffStat>(
        const float* data, const float* penalties, int T, int J,
        double mean, double scale);
template void SIMPLE_changepoint::ll_difference<
        SIMPLE_changepoint::NormalVarSuffStat>(
        const float* data, int prev_change, int next_change, int start,
        int end, double* ll_diff, double mean, double scale);
template std::list<int> SIMPLE_changepoint::find_changes<
        SIMPLE_changepoint::PoissonSuffStat>(
        const float* data, const float* penalties, int T, int J,
        double mean, double scale);
template void SIMPLE_changepoint::ll_difference<
        SIMPLE_changepoint::PoissonSuffStat>(
        const float* data, int prev_change, int next_change, int start,
        int end, double* ll_diff, double mean, double scale);
template std::list<int> SIMPLE_changepoint::find_changes<
        SIMPLE_changepoint::BernoulliSuffStat>(
        const float* data, const float* penalties, int T, int J,
        double mean, double scale);
template void SIMPLE_changepoint::ll_difference<
        SIMPLE_changepoint::BernoulliSuffStat>(
        const float* data, int prev_change, int next_change, int start,
        int end, double* ll_diff, double mean, double scale);
template std::list<int> SIMPLE_changepoint::find_changes<
        SIMPLE_changepoint::LaplaceScaleSuffStat>(
        const float* data, const float* penalties, int T, int J,
        double mean, double scale);
template void SIMPLE_changepoint::ll_difference<
        SIMPLE_changepoint::LaplaceScaleSuffStat>(
        const float* data, int prev_change, int next_change, int start,
        int end, double* ll_diff, double mean, double scale);
template std::list<int> SIMPLE_changepoint::find_changes<
        SIMPLE_changepoint::LaplaceMeanSuffStat>(
        const float* data, const float* penalties, int T, int J,
        double mean, double scale);
template void SIMPLE_changepoint::ll_difference<
        SIMPLE_changepoint::LaplaceMeanSuffStat>(
        const float* data, int prev_change, int next_change, int start,
        int end, double* ll_diff, double mean, double scale);
