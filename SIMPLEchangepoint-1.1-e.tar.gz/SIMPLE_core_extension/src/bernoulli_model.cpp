#include "bernoulli_model.hpp"
#include <math.h>
#include <limits>

using namespace SIMPLE_changepoint;

BernoulliSuffStat::BernoulliSuffStat(int _t, double _mean, double _scale) {
    t = _t;
    n = 0;
    xsum = 0;
    cost = 0;
    prune_t = -1;
}

void BernoulliSuffStat::add(double x) {
    ++n;
    xsum += x;
}

double BernoulliSuffStat::ll() {
    if (n < MIN_SEP)
        return -std::numeric_limits<double>::infinity();
    else if (xsum == 0 || xsum == n)
        return 0;
    else
        return xsum * log(xsum/n) + (n-xsum) * log(1 - xsum/n);
}
