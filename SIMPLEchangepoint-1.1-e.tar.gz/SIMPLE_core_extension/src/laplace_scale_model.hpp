#ifndef __simple_changepoint_laplace_scale_model_hpp__
#define __simple_changepoint_laplace_scale_model_hpp__

namespace SIMPLE_changepoint {

    struct LaplaceScaleSuffStat {
        LaplaceScaleSuffStat(int _t, double _mean, double _scale);
        void add(double x);
        double ll();

        int t;
        double mean;
        int n;
        double absxsum;
        double cost;
        int prune_t;
        const static int MIN_SEP = 1;
    };

}
#endif
