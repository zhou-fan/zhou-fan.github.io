#include "poisson_model.hpp"
#include <math.h>
#include <limits>

using namespace SIMPLE_changepoint;

PoissonSuffStat::PoissonSuffStat(int _t, double _mean, double _scale) {
    t = _t;
    n = 0;
    xsum = 0;
    logxfactsum = 0;
    cost = 0;
    prune_t = -1;
}

void PoissonSuffStat::add(double x) {
    ++n;
    xsum += x;
    logxfactsum += lgamma(x+1);
}

double PoissonSuffStat::ll() {
    if (n < MIN_SEP)
        return -std::numeric_limits<double>::infinity();
    else if (xsum == 0)
        return 0;
    else
        return xsum * log(xsum/n) - xsum - logxfactsum;
}
