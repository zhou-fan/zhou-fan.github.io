#ifndef __simple_changepoint_laplace_mean_model_hpp__
#define __simple_changepoint_laplace_mean_model_hpp__

#include <queue>

namespace SIMPLE_changepoint {

    struct LaplaceMeanSuffStat {
        LaplaceMeanSuffStat(int _t, double _mean, double _scale);
        void add(double x);
        double ll();

        std::priority_queue<double, std::vector<double>,
            std::greater<double> > highs;
        std::priority_queue<double, std::vector<double>,
            std::less<double> > lows;
        int t;
        double scale;
        int n;
        double med;
        double total_var;
        double cost;
        int prune_t;
        const static int MIN_SEP = 1;
    };

}
#endif
