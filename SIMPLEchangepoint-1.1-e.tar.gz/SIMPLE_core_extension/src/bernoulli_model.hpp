#ifndef __simple_changepoint_bernoulli_model_hpp__
#define __simple_changepoint_bernoulli_model_hpp__

namespace SIMPLE_changepoint {

    struct BernoulliSuffStat {
        BernoulliSuffStat(int _t, double _mean, double _scale);
        void add(double x);
        double ll();

        int t;
        int n;
        double xsum;
        double cost;
        int prune_t;
        const static int MIN_SEP = 1;
    };

}
#endif
