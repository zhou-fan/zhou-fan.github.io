#include "normal_mean_var_model.hpp"
#include <math.h>
#include <limits>

const static double PI = 3.141592654;

using namespace SIMPLE_changepoint;

NormalMeanVarSuffStat::NormalMeanVarSuffStat(int _t, double _mean,
        double _scale) {
    t = _t;
    n = 0;
    xsum = 0;
    xsqsum = 0;
    cost = 0;
    prune_t = -1;
}

void NormalMeanVarSuffStat::add(double x) {
    ++n;
    xsum += x;
    xsqsum += x*x;
}

double NormalMeanVarSuffStat::ll() {
    if (xsqsum == 0 || n < MIN_SEP)
        return -std::numeric_limits<double>::infinity();
    else {
        double var = xsqsum / n - (xsum / n) * (xsum / n);
        var = (var > 0 ? var : 0);
        return -n/2.0 * (1 + log(2 * PI * var));
    }
}

