from GraphSegment import *
import numpy as np
np.set_printoptions(precision=3)

np.random.seed(123)

mu = np.array([0,0,0,0,0,1,1,1,1,1])
data = mu + np.random.normal(size=10)*0.1
data[1] = np.nan
data[8] = np.nan
edges = Edges_1D(10)
print('Running 1D, uniform weights')
lamb = 0.5
out = GraphSegment(data,edges,lamb,delta=0.01)
print('Truth:')
print(mu)
print('Output:')
print(out)

mu = np.zeros((10,10))
mu[:5,:5] = 1
data = mu + np.random.normal(size=(10,10))*0.1
data[2,3] = np.nan
data[9,6] = np.nan
edges = Edges_2D(10,10)
print('Running 2D, uniform weights')
lamb = 0.5
out = GraphSegment(data.reshape(-1),edges,lamb,delta=0.01)
out = out.reshape((10,10))
print('Truth:')
print(mu)
print('Output:')
print(out)
print('Running 2D, effective resistance weights')
res = EffectiveResistance(edges)
out = GraphSegment(data.reshape(-1),edges,lamb,weights=res,delta=0.01)
out = out.reshape((10,10))
print('Truth:')
print(mu)
print('Output:')
print(out)

