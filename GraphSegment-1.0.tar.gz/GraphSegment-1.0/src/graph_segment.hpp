#ifndef __GRAPH_SEGMENT_HPP__
#define __GRAPH_SEGMENT_HPP__

#include <vector>
#include <utility>
#include <limits>

namespace GraphSegment {

    // Value representing missing data
    const double MISSING = std::numeric_limits<double>::max();

    void graph_segment(const std::vector<double>& data,
            const std::vector<std::pair<int,int> >& edges, double lambda,
            const std::vector<double>& weights,
            double delta, double mu_min, double mu_max, double tau,
            std::vector<double>& mu_hat, int max_iters=100,
            bool verbose=true);

};

#endif
