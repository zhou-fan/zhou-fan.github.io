#include <Python.h>
#include <numpy/arrayobject.h>
#include <vector>
#include <sstream>
#include <utility>
#include "graph_segment.hpp"

static PyObject* py_graph_segment(PyObject* self, PyObject* args) {
    // Read Python arguments
    PyObject* py_data;
    PyObject* py_missing;
    PyObject* py_edges;
    double lambda = 0;
    PyObject* py_weights;
    double delta = 0;
    double mu_min = 0;
    double mu_max = 0;
    double tau = 0;
    int max_iters = 0;
    int verbose = 0;
    if (!PyArg_ParseTuple(args, "OOOdOddddii", &py_data, &py_missing, &py_edges,
                &lambda, &py_weights, &delta, &mu_min, &mu_max, &tau, &max_iters,
                &verbose))
        return NULL;
    if (!PyList_Check(py_edges)) {
        PyErr_SetString(PyExc_ValueError,
                "Invalid format for adjacency list");
        return NULL;
    }
    // Convert edges
    std::vector<std::pair<int, int> > edges;
    for (Py_ssize_t i = 0; i < PyList_Size(py_edges); ++i) {
        PyObject* py_edge = PyList_GetItem(py_edges, i);
        if (!PyTuple_Check(py_edge) || PyTuple_Size(py_edge) != 2) {
            PyErr_SetString(PyExc_ValueError,
                    "Invalid format for adjacency list");
            return NULL;
        }
        int u = (int)PyInt_AsLong(PyTuple_GetItem(py_edge,0));
        int v = (int)PyInt_AsLong(PyTuple_GetItem(py_edge,1));
        if (PyErr_Occurred()) {
            PyErr_SetString(PyExc_ValueError,
                    "Invalid format for adjacency list");
            return NULL;
        }
        edges.push_back(std::make_pair(u,v));
    }
    // Convert data, handle missing values
    PyObject* np_data = PyArray_FROM_OTF(py_data, NPY_FLOAT64,
            NPY_IN_ARRAY);
    PyObject* np_missing = PyArray_FROM_OTF(py_missing, NPY_BOOL,
            NPY_IN_ARRAY);
    if (np_data == NULL || np_missing == NULL) {
        Py_XDECREF(np_data);
        Py_XDECREF(np_missing);
        PyErr_SetString(PyExc_ValueError, "Invalid input data");
        return NULL;
    }
    std::vector<double> data((double*)PyArray_DATA(np_data),
            ((double*)PyArray_DATA(np_data)) + PyArray_DIM(np_data,0));
    for (unsigned i = 0; i < data.size(); ++i) {
        char* missing = (char*)PyArray_GETPTR1(np_missing,i);
        if (*missing != 0)
            data[i] = GraphSegment::MISSING;
    }
    // Convert weights
    PyObject* np_weights = PyArray_FROM_OTF(py_weights, NPY_FLOAT64,
            NPY_IN_ARRAY);
    if (np_weights == NULL || PyArray_DIM(np_weights,0)
            != (int)edges.size()) {
        Py_XDECREF(np_data);
        Py_XDECREF(np_missing);
        Py_XDECREF(np_weights);
        PyErr_SetString(PyExc_ValueError, "Invalid weights");
        return NULL;
    }
    std::vector<double> weights((double*)PyArray_DATA(np_weights),
            ((double*)PyArray_DATA(np_weights))+PyArray_DIM(np_weights,0));
    // Run algorithm
    std::vector<double> mu_hat(data.size());
    try {
        GraphSegment::graph_segment(data, edges, lambda, weights, delta, mu_min,
                mu_max, tau, mu_hat, max_iters, (bool)verbose);
    } catch (std::exception& e) {
        Py_XDECREF(np_data);
        Py_XDECREF(np_missing);
        Py_XDECREF(np_weights);
        std::stringstream ss;
        ss << "Execution error: " << e.what();
        PyErr_SetString(PyExc_RuntimeError, ss.str().c_str());
        return NULL;
    }
    // Output mu_hat
    npy_intp out_dims = mu_hat.size();
    PyObject* py_mu_hat = PyArray_SimpleNew(1, &out_dims, NPY_FLOAT64);
    std::copy(mu_hat.begin(), mu_hat.end(),
            (double*)PyArray_DATA(py_mu_hat));
    return py_mu_hat;
}

static PyMethodDef methods[] = {
    {"graph_segment", py_graph_segment, METH_VARARGS, ""},
    {NULL, NULL, 0, NULL}
};

PyMODINIT_FUNC
init_c_funcs(void) {
    (void)Py_InitModule("_c_funcs", methods);
    import_array();
}
