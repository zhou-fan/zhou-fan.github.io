#include "graph_segment.hpp"
#include "graph.h"
#include <limits>
#include <iostream>
#include <numeric>
#include <map>

const double INF = std::numeric_limits<double>::infinity();

inline double vpen(double x, double y) {
    return 0.5*(x-y)*(x-y);
}

void construct_graph(const std::vector<double>& data,
        const std::vector<double>& mu_hat,
        const std::vector<std::pair<int, int> >& edges, double lambda,
        const std::vector<double>& weights, double mu,
        Graph<double, double, double>& g) {
    g.reset();
    g.add_node(data.size());
    for (unsigned i = 0; i < data.size(); ++i) {
        if (data[i] != GraphSegment::MISSING) {
            if (mu_hat[i] == mu)
                g.add_tweights(i, vpen(mu,data[i]), INF);
            else
                g.add_tweights(i, vpen(mu,data[i]), vpen(mu_hat[i],data[i]));
        } else
            g.add_tweights(i, 0, 0);
    }
    for (unsigned i = 0; i < edges.size(); ++i) {
        if (mu_hat[edges[i].first] == mu_hat[edges[i].second]) {
            if (mu_hat[edges[i].first] == mu)
                g.add_edge(edges[i].first, edges[i].second, 0, 0);
            else
                g.add_edge(edges[i].first, edges[i].second,
                        lambda*weights[i], lambda*weights[i]);
        }
        else {
            int newnode = g.add_node();
            g.add_tweights(newnode, 0, lambda*weights[i]);
            if (mu_hat[edges[i].first] == mu)
                g.add_edge(edges[i].first, newnode, 0, 0);
            else
                g.add_edge(edges[i].first, newnode, lambda*weights[i],
                        lambda*weights[i]);
            if (mu_hat[edges[i].second] == mu)
                g.add_edge(edges[i].second, newnode, 0, 0);
            else
                g.add_edge(edges[i].second, newnode, lambda*weights[i],
                        lambda*weights[i]);
        }
    }
}

void GraphSegment::graph_segment(const std::vector<double>& data,
        const std::vector<std::pair<int,int> >& edges, double lambda,
        const std::vector<double>& weights,
        double delta, double mu_min, double mu_max, double tau,
        std::vector<double>& mu_hat,
        int max_iters, bool verbose) {
    double mean = 0;
    int nonmissing = 0;
    for (unsigned i = 0; i < data.size(); ++i) {
        if (data[i] != GraphSegment::MISSING) {
            nonmissing += 1;
            mean += data[i];
        }
    }
    mean /= nonmissing;
    for (unsigned i = 0; i < mu_hat.size(); ++i)
        mu_hat[i] = mean;

    int Zmin = (int)(mu_min/delta)-1;
    int Zmax = (int)(mu_max/delta)+1;
    Graph<double, double, double> g(data.size()+edges.size(),
            2*edges.size());
    double prev_flow = INF;
    int iter = 1;
    for (; iter <= max_iters; ++iter) {
        if (verbose)
            std::cout << "Iteration " << iter << std::endl;
        bool changed = false;
        for (int Z = Zmin; Z <= Zmax; ++Z) {
            double mu = Z*delta;
            if (verbose)
                std::cout << "  mu = " << mu << std::endl;
            construct_graph(data,mu_hat,edges,lambda,weights,mu,g);
            double flow = g.maxflow();
            if (flow < prev_flow-tau) {
                changed = true;
                prev_flow = flow;
                for (unsigned j = 0; j < mu_hat.size(); ++j) {
                    if (g.what_segment(j) ==
                        Graph<double,double,double>::SINK)
                    mu_hat[j] = mu;
                }
            }
        }
        if (!changed) {
            ++iter;
            break;
        }
    }
    if (iter >= max_iters) {
        std::cerr << "WARNING: Did not converge" << std::endl;
    } else if (verbose)
        std::cout << "CONVERGED" << std::endl;
    // Replace blocks with mean values
    std::map<double, std::vector<double> > recenter;
    for (unsigned j = 0; j < mu_hat.size(); ++j) {
        if (data[j] != GraphSegment::MISSING)
            recenter[mu_hat[j]].push_back(data[j]);
    }
    std::map<double, double> means;
    for (std::map<double, std::vector<double> >::iterator iter
            = recenter.begin(); iter != recenter.end(); ++iter) {
        std::vector<double>& vec = iter->second;
        if (vec.size() > 0)
            means[iter->first] = std::accumulate(vec.begin(), vec.end(),
                    0.0)/vec.size();
        else
            means[iter->first] = iter->first;
    }
    for (unsigned j = 0; j < mu_hat.size(); ++j)
        mu_hat[j] = means[mu_hat[j]];
}
