from distutils.core import setup
from distutils.extension import Extension
from distutils.sysconfig import get_python_inc
import numpy

setup(name='GraphSegment',
        version='1.0',
        packages=['GraphSegment'],
        ext_modules=[Extension('GraphSegment._c_funcs',
            ['src/graph_segment.cpp',
                'src/py_extension.cpp',
                'src/graph.cpp',
                'src/maxflow.cpp'],
            include_dirs=[get_python_inc(), numpy.get_include()])],
        headers=['src/block.h', 'src/graph.h', 'src/graph_segment.hpp']
        )
