import numpy as np
import _c_funcs

def Edges_1D(n):
    ''' Get edge list for linear chain graph of length n '''
    return [(i,i+1) for i in range(n-1)]

def Edges_2D(nrow,ncol):
    ''' Get edge list for 2D lattice graph of dimensions nrow x ncol '''
    def v(i,j):
        return i*ncol+j
    edges = []
    for i in range(nrow-1):
        for j in range(ncol-1):
            edges.append((v(i,j),v(i+1,j)))
            edges.append((v(i,j),v(i,j+1)))
    for i in range(nrow-1):
        edges.append((v(i,ncol-1),v(i+1,ncol-1)))
    for j in range(ncol-1):
        edges.append((v(nrow-1,j),v(nrow-1,j+1)))
    return edges

def EffectiveResistance(edges):
    ''' Compute all effective edge resistances

    This directly inverts the Laplacian and can only be used for small graphs
    '''
    nverts = np.max(np.array(edges, dtype=int))+1
    L = np.zeros((nverts,nverts))
    for e in edges:
        L[e[0],e[1]] = -1
        L[e[1],e[0]] = -1
        L[e[0],e[0]] += 1
        L[e[1],e[1]] += 1
    Linv = np.linalg.pinv(L)
    R = [Linv[e[0],e[0]]+Linv[e[1],e[1]]-Linv[e[0],e[1]]-Linv[e[1],e[0]]
            for e in edges]
    return np.array(R)

def GraphSegment(data, edges, lamb, weights=None, delta=None, mu_min=None,
        mu_max=None, tau=1e-10, max_iters=100, verbose=True):
    ''' l_0 estimation of a signal on a graph

    Inputs: 
    data -- Data array Y of length n
    edges -- List of (i,j) pairs, 0<=i,j<=n-1, corresponding to elements of data
    lamb -- Penalty parameter
    weights -- List or array of edge weights, default 1.0 for all edges
    delta -- Discretization size, default 1.0/sqrt(n)
    mu_min -- Minimum value of mu, default min(data)
    mu_max -- Maximum value of mu, default max(data)
    tau -- Convergence tolerance, default 1e-10
    max_iters -- Maximum number of iterations

    Output: mu_hat, array of length n containing the estimated signal

    Approximately minimizes 1/2*||Y-mu||^2+lamb*||D mu||_w using
    alpha-expansion procedure of Boykov, Veksler, Zabih (2001).

    Can handle missing data by setting missing values to numpy.nan. In this case,
    tau should be non-zero.
    '''
    # Default initializations
    if weights is None:
        weights = np.ones(len(edges))
    if delta is None:
        delta = 1.0/np.sqrt(len(data))
    if mu_min is None:
        mu_min = np.nanmin(data)
    if mu_max is None:
        mu_max = np.nanmax(data)
    # Convert types
    weights = np.array(weights,dtype=float)
    data = np.array(data,dtype=float)
    edges = [(e[0],e[1]) for e in edges]
    # Check input
    for e in edges:
        for v in e:
            if v > len(data)-1 or v < 0:
                raise RuntimeError, "Edge indices out of bounds"
    if len(weights) != len(edges):
        raise RuntimeError, "Invalid weights"
    # Get missing data elements
    missing = np.isnan(data)
    return _c_funcs.graph_segment(data, missing, edges, lamb, weights, delta, mu_min,
            mu_max, tau, max_iters, verbose)

