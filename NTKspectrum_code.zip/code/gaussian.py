import numpy as np
from simulate_NN import simulate

np.random.seed(123)

n = 3000
d0 = 1000
d = [6000,6000,6000,6000,6000]

X0 = np.random.normal(size=(d0,n))
simulate(X0,d,ylim=[0,200],fname='gaussian1')

